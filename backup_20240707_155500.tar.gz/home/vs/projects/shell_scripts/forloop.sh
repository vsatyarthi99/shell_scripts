#!/bin/bash
list=(1,2,3)
for num in "${list[@]}"; do
	echo $num
done

