#!/bin/bash

echo "Hello, this is file2"
rm -r directory3
mkdir directory3
cd directory3
touch file3

