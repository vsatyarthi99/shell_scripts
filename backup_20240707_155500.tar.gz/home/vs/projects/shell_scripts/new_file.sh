apple=5
if [ "$apple" -le 2 ]; then
	echo "anbody can access it"
else
	echo "nobody can access it"
fi	
