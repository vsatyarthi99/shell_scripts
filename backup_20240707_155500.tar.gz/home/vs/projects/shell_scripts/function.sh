#!/bin/bash

# how to create a function

display_name() {
	echo "My name is Vaishnavi Satyarthi!"
}
display_name
