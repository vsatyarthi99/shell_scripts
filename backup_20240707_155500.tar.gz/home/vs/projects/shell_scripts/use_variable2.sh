#!/bin/bash
echo "Please enter your name:"
read name
echo "Hello $name, Please enter your age:"
read age
echo "Hello $name, you are $age years old"

